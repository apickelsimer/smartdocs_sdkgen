var resp = JSON.parse(context.getVariable("response.content"));
var url = resp.link.replace("http://35.188.140.246/api","https://api.dynolab.io/swagger");
var obj = new Object(); obj['url'] = url;
context.setVariable("response.content",JSON.stringify(obj));